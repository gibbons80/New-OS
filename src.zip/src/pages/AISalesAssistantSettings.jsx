import React from 'react';

export default function AISalesAssistantSettings({ user }) {
  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center">
        <p className="text-slate-500">AI Sales Assistant Settings - Coming Soon</p>
      </div>
    </div>
  );
}